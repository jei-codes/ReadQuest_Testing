# Separation verification

For the current v0.3.0 verification, see TEACHER_REGISTRATION.md. The notes below describe v0.2.0 and the earlier separation work.

Input: readquest-github-upload.zip. The original archive was left unchanged.

- Backend TypeScript check passed.
- Frontend TypeScript check and Vite production build passed.
- All twelve Chrome integration tests passed using simulated Supabase responses, including rejection of both wrong-form logins and the Teacher display name.
- Frontend/src contains no direct Supabase SDK imports, table queries or RPC calls.
- Existing registration, saved answers, role routing, teacher roster, pagination, session restoration, errors and mobile layout are covered by the integration tests.

The production build retains a non-blocking bundle-size warning (about 572 kB before gzip).

No live accounts were registered, database records changed, SQL definitions applied or learner codes reset. Frontend tests do not prove live database authorization or trigger behavior.

Use README.md for root-level installation and TEAM_GUIDE.md for folder ownership. Backend/src is browser-bundled API code; server-side grading and permissions remain in Supabase.
