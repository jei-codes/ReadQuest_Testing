// Serve a test-only Supabase configuration; never use the live project in tests.
import { createServer } from 'vite';
import { fileURLToPath } from 'node:url';
process.chdir(fileURLToPath(new URL('..', import.meta.url)));
import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
process.env.VITE_SUPABASE_URL = 'https://readquest-test.supabase.co';
process.env.VITE_SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_mock_only';
const server = await createServer({ server: { host: '127.0.0.1', port: 5175, strictPort: true } });
try {
  await server.listen();
  const child = spawn(process.execPath, [require.resolve('@playwright/test/cli'), 'test', ...process.argv.slice(2)], {
    stdio: 'inherit', env: process.env,
  });
  process.exitCode = await new Promise((resolve, reject) => {
    child.once('error', reject);
    child.once('exit', (code) => resolve(code ?? 1));
  });
} finally {
  await server.close();
}

