import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';
import { fileURLToPath } from 'node:url';
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { '@readquest/backend': fileURLToPath(new URL('../Backend/src/index.ts', import.meta.url)) },
  },
});
