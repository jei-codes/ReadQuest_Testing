import { test, expect } from '@playwright/test';
import type { Page } from '@playwright/test';

const studentId = '00000000-0000-4000-8000-000000000001';
const teacherId = '00000000-0000-4000-8000-000000000002';
const student = { id: studentId, display_name: 'Maya', learner_code: 'RQ-001' };
const teacher = { id: teacherId, display_name: 'Teacher One' };
const answer = { learner_id: studentId, question_id: 'practice-cause-001', selected_answer: 'Rain fell all night.',
  is_correct: true, skill: 'cause_and_effect', created_at: '2026-10-13T01:00:00Z' };

function authSession(id = studentId) {
  const expires = Math.floor(Date.now() / 1000) + 3600;
  const user = { id, aud: 'authenticated', role: 'authenticated', email: id === teacherId ? 'teacher@example.test' : 'student@example.test',
    app_metadata: { provider: 'email', providers: ['email'] }, user_metadata: { display_name: 'Maya' }, created_at: '2026-10-01T00:00:00Z' };
  const encode = (value: object) => Buffer.from(JSON.stringify(value)).toString('base64url');
  return { access_token: `${encode({ alg: 'HS256', typ: 'JWT' })}.${encode({ sub: id, exp: expires, role: 'authenticated' })}.mock`,
    refresh_token: 'mock-refresh', token_type: 'bearer', expires_in: 3600, expires_at: expires, user };
}

type MockOptions = { role?: 'teacher' | 'learner' | 'pending_teacher'; confirmation?: boolean; badLogin?: boolean; saved?: boolean; profileError?: boolean; many?: boolean; profileDelay?: number; missingTeacherSetup?: boolean; signupError?: boolean };
async function mockSupabase(page: Page, options: MockOptions = {}) {
  const state = { signup: null as Record<string, unknown> | null, submitted: null as Record<string, unknown> | null,
    saved: options.saved ? answer : null, profileError: options.profileError ?? false, learnerFilters: [] as string[], unexpected: [] as string[],
    role: options.role ?? 'learner', signupError: options.signupError ?? false };
  await page.route('https://*.supabase.co/**', async (route) => {
    const request = route.request();
    const url = new URL(request.url());
    if (url.hostname !== 'readquest-test.supabase.co') {
      state.unexpected.push(request.url());
      return route.abort(); // Never send test credentials or mutations to the real project.
    }
    const respond = (data: unknown, status = 200, headers = {}) => route.fulfill({ status,
      contentType: 'application/json', headers: { 'access-control-expose-headers': 'content-range', ...headers }, body: JSON.stringify(data) });
    if (request.method() === 'OPTIONS') return route.fulfill({ status: 204 });
    if (url.pathname.endsWith('/signup')) {
      state.signup = request.postDataJSON();
      if (state.signupError) return respond({ code: 'over_email_send_rate_limit', msg: 'Email rate limit exceeded' }, 429);
      // Mimic the database creating a pending request, never an approved teacher, on teacher signup.
      const metadata = state.signup?.data as Record<string, unknown> | undefined;
      if (metadata?.requested_role === 'teacher') state.role = 'pending_teacher';
      const session = authSession(state.role === 'learner' ? studentId : teacherId);
      return respond(options.confirmation ? { user: session.user } : session);
    }
    if (url.pathname.endsWith('/rpc/readquest_teacher_registration_version')) {
      return options.missingTeacherSetup ? respond({ message: 'Function not found' }, 404) : respond('0.3.0');
    }
    if (url.pathname.endsWith('/token')) {
      if (options.badLogin) return respond({ code: 'invalid_credentials', msg: 'Invalid login credentials' }, 400);
      return respond(authSession(state.role === 'learner' ? studentId : teacherId));
    }
    if (url.pathname.endsWith('/logout')) return route.fulfill({ status: 204 });
    if (url.pathname.endsWith('/user')) return respond(authSession(state.role === 'learner' ? studentId : teacherId).user);
    if (url.pathname.endsWith('/teachers')) {
      // Delayed lookup catches accidental redirects before role verification has finished.
      if (options.profileDelay) await new Promise((resolve) => setTimeout(resolve, options.profileDelay));
      if (state.profileError) return respond({ message: 'Test profile unavailable', code: '42501' }, 403);
      return respond(state.role === 'teacher' ? teacher : null);
    }
    if (url.pathname.endsWith('/teacher_registration_requests')) {
      return respond(state.role === 'pending_teacher' ? { id: teacherId, display_name: 'Teacher' } : null);
    }
    if (url.pathname.endsWith('/Learners')) {
      if (url.searchParams.get('id')?.startsWith('eq.')) return respond(student);
      const roster = options.many ? Array.from({ length: 27 }, (_, i) => ({ id: `00000000-0000-4000-8000-${String(i + 100).padStart(12, '0')}`,
        display_name: `Learner ${i + 1}`, learner_code: `RQ-${String(i + 1).padStart(3, '0')}` })) : [student, { id: 'new-student', display_name: 'Pip', learner_code: 'RQ-013' }];
      const offset = Number(url.searchParams.get('offset') ?? 0);
      const limit = Number(url.searchParams.get('limit') ?? 25);
      return respond(roster.slice(offset, offset + limit), 200, { 'content-range': `${offset}-${Math.min(offset + limit, roster.length) - 1}/${roster.length}` });
    }
    if (url.pathname.endsWith('/practice_responses')) {
      state.learnerFilters.push(url.searchParams.get('learner_id') ?? '');
      if (request.method() === 'HEAD') return route.fulfill({ status: 200, headers: { 'access-control-expose-headers': 'content-range', 'content-range': `0-0/${url.searchParams.get('learner_id') === 'eq.new-student' ? 0 : options.many ? 21 : 1}` } });
      if (state.role !== 'teacher') return respond(state.saved);
      if (url.searchParams.get('learner_id') === 'eq.new-student') return respond([], 200, { 'content-range': '*/0' });
      const records = options.many ? Array.from({ length: 21 }, (_, i) => ({ ...answer, question_id: `question-${i + 1}` })) : [answer];
      const offset = Number(url.searchParams.get('offset') ?? 0);
      const limit = Number(url.searchParams.get('limit') ?? 20);
      return respond(records.slice(offset, offset + limit), 200, { 'content-range': `${offset}-${Math.min(offset + limit, records.length) - 1}/${records.length}` });
    }
    if (url.pathname.endsWith('/rpc/submit_mini_readquest_answer')) {
      state.submitted = request.postDataJSON();
      state.saved = { ...answer, selected_answer: String(state.submitted?.p_answer), is_correct: state.submitted?.p_answer === answer.selected_answer };
      return respond(state.saved);
    }
    state.unexpected.push(url.pathname);
    return respond({ message: 'Unexpected test request' }, 500);
  });
  return state;
}

async function login(page: Page, path = '/login/student') {
  await page.goto(path);
  await page.getByLabel('Email', { exact: true }).fill(path === '/login/teacher' ? 'teacher@example.test' : 'student@example.test');
  await page.getByLabel('Password', { exact: true }).fill('test-password');
  await page.getByRole('button', { name: 'Login', exact: true }).click();
}

test('welcome design and registration use exactly the requested three fields', async ({ page }) => {
  await mockSupabase(page);
  await page.goto('/');
  await expect(page.getByRole('heading', { name: "Who's Joining The Adventure?" })).toBeVisible();
  await page.getByRole('link', { name: /Student Begin/ }).click();
  await page.getByRole('button', { name: 'Create an account' }).click();
  await expect(page.locator('form input')).toHaveCount(3);
  await expect(page.getByLabel('Display name', { exact: true })).toBeVisible();
  await expect(page.getByLabel('Email', { exact: true })).toHaveAttribute('type', 'email');
  await expect(page.getByLabel('Password', { exact: true })).toHaveAttribute('minlength', '8');
  await expect(page.getByLabel('Confirm password')).toHaveCount(0);
});

test('registration sends display_name and opens the learner activity', async ({ page }) => {
  const state = await mockSupabase(page);
  await page.goto('/login/student');
  await page.getByRole('button', { name: 'Create an account' }).click();
  await page.getByLabel('Display name', { exact: true }).fill(' Maya ');
  await page.getByLabel('Email', { exact: true }).fill('student@example.test');
  await page.getByLabel('Password', { exact: true }).fill('test-password');
  await page.getByRole('button', { name: 'Register', exact: true }).click();
  await expect(page).toHaveURL(/\/learn$/);
  await expect(page.getByRole('heading', { name: 'Welcome, Maya!' })).toBeVisible();
  expect(state.signup?.data).toEqual({ display_name: 'Maya' });
  expect(state.signup?.email).toBe('student@example.test');
  expect(state.unexpected).toEqual([]);
});

test('email confirmation branch keeps the message and disables repeated signup', async ({ page }) => {
  await mockSupabase(page, { confirmation: true });
  await page.goto('/login/student');
  await page.getByRole('button', { name: 'Create an account' }).click();
  await page.getByLabel('Display name').fill('Maya');
  await page.getByLabel('Email', { exact: true }).fill('student@example.test');
  await page.getByLabel('Password', { exact: true }).fill('test-password');
  await page.getByRole('button', { name: 'Register', exact: true }).click();
  await expect(page.getByRole('status')).toContainText('Check your email');
  await expect(page.getByRole('button', { name: 'Register', exact: true })).toBeDisabled();
  await page.getByRole('button', { name: 'Back to Login' }).click();
  await expect(page.getByRole('button', { name: 'Login', exact: true })).toBeEnabled();
});

test('failed login shows an error and allows another attempt', async ({ page }) => {
  await mockSupabase(page, { badLogin: true });
  await login(page);
  await expect(page.getByRole('alert')).toContainText('Invalid login credentials');
  await expect(page.getByRole('button', { name: 'Login', exact: true })).toBeEnabled();
});

test('learner uses Student Login and saved answers persist', async ({ page }) => {
  const state = await mockSupabase(page);
  await page.goto('/login/teacher');
  await expect(page.getByRole('button', { name: 'Create an account' })).toBeVisible();
  await login(page, '/login/student');
  await expect(page).toHaveURL(/\/learn$/);
  await page.getByRole('radio', { name: 'Rain fell all night.' }).check();
  await page.getByRole('button', { name: 'Submit answer' }).click();
  await expect(page.getByText('Your first answer is saved.')).toBeVisible();
  expect(state.submitted).toEqual({ p_answer: 'Rain fell all night.' });
  await page.reload();
  await expect(page.getByText('Your first answer is saved.')).toBeVisible();
  await expect(page.getByRole('radio', { name: 'Rain fell all night.' })).toBeDisabled();
  expect(state.learnerFilters.every((filter) => filter === `eq.${studentId}`)).toBe(true);
  await page.goto('/teacher');
  await expect(page).toHaveURL(/\/learn$/);
  await page.getByRole('button', { name: 'Log out', exact: true }).click();
  await expect(page).toHaveURL(/\/login\/student$/);
  await expect(page.getByLabel('Password', { exact: true })).toHaveValue('');
  expect(state.unexpected).toEqual([]);
});

test('approved teacher can view all learners, saved answers, empty records and restore session', async ({ page }) => {
  const state = await mockSupabase(page, { role: 'teacher' });
  await login(page, '/login/teacher');
  await expect(page).toHaveURL(/\/teacher$/);
  // The supplied database name is intentionally different; the requested UI name is Teacher.
  await expect(page.getByRole('heading', { name: 'Welcome, Teacher', exact: true })).toBeVisible();
  await expect(page.locator('.rq-account-name')).toHaveText('Teacher');
  await expect(page.getByRole('heading', { name: 'Learners (2)' })).toBeVisible();
  await expect(page.getByText(`Learner ID: ${studentId}`)).toBeVisible();
  await expect(page.getByRole('cell', { name: 'Rain fell all night.' })).toBeVisible();
  await page.getByRole('button', { name: /Pip RQ-013/ }).click();
  await expect(page.getByText('This learner has not saved a practice answer yet.')).toBeVisible();
  await page.reload();
  await expect(page.locator('.rq-account-name')).toHaveText('Teacher');
  await expect(page.getByRole('heading', { name: 'Learners (2)' })).toBeVisible();
  await page.getByRole('button', { name: 'Refresh records' }).click();
  await expect(page.getByRole('cell', { name: 'Rain fell all night.' })).toBeVisible();
  expect(state.unexpected).toEqual([]);
});

test('teacher roster and responses paginate', async ({ page }) => {
  await mockSupabase(page, { role: 'teacher', many: true });
  await login(page, '/login/teacher');
  await expect(page.getByRole('heading', { name: 'Learners (27)' })).toBeVisible();
  await page.getByRole('navigation', { name: 'Response pages' }).getByRole('button', { name: 'Next' }).click();
  await expect(page.getByRole('cell', { name: 'question-21', exact: true })).toBeVisible();
  await page.getByRole('navigation', { name: 'Learner pages' }).getByRole('button', { name: 'Next' }).click();
  await expect(page.getByRole('button', { name: /Learner 26 RQ-026/ })).toBeVisible();
});

test('profile failure has retry and logout instead of a blank dashboard', async ({ page }) => {
  const state = await mockSupabase(page, { profileError: true });
  // Restore an existing session to test errors after login, separately from login validation.
  await page.addInitScript((session) => {
    localStorage.setItem('sb-readquest-test-auth-token', JSON.stringify(session));
  }, authSession());
  await page.goto('/learn');
  await expect(page.getByRole('alert')).toContainText('Test profile unavailable');
  await expect(page.getByRole('button', { name: 'Log out', exact: true })).toBeVisible();
  state.profileError = false;
  await page.getByRole('button', { name: 'Try again' }).click();
  await expect(page.getByRole('heading', { name: 'Welcome, Maya!' })).toBeVisible();
});

test('mobile registration and teacher dashboard fit the viewport', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await mockSupabase(page, { role: 'teacher' });
  await page.goto('/login/student');
  await page.getByRole('button', { name: 'Create an account' }).click();
  await expect(page.getByLabel('Display name')).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  await page.screenshot({ path: 'test-results/registration-mobile.png', fullPage: true });
  await login(page, '/login/teacher');
  await expect(page.getByRole('heading', { name: 'Learners (2)' })).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  await page.screenshot({ path: 'test-results/teacher-mobile.png', fullPage: true });
});

// Both mismatched combinations must remain signed out, including after a page reload.
for (const actualRole of ['learner', 'teacher'] as const) {
  test(`${actualRole} cannot sign in through the other role's login form`, async ({ page }) => {
    const wrongPath = actualRole === 'learner' ? '/login/teacher' : '/login/student';
    const correctPath = actualRole === 'learner' ? '/login/student' : '/login/teacher';
    const destination = actualRole === 'learner' ? /\/learn$/ : /\/teacher$/;
    const message = actualRole === 'learner'
      ? 'This is a student account. Please use Student Login.'
      : 'This is a teacher account. Please use Teacher Login.';
    const state = await mockSupabase(page, { role: actualRole, profileDelay: 350 });
    await login(page, wrongPath);
    await expect(page.getByRole('heading', { name: /Welcome,/ })).toHaveCount(0);
    await expect(page.getByRole('alert')).toHaveText(message);
    expect(new URL(page.url()).pathname).toBe(wrongPath);
    await expect(page.getByRole('button', { name: 'Log out', exact: true })).toHaveCount(0);
    expect(state.learnerFilters).toEqual([]);
    expect(await page.evaluate(() => localStorage.getItem('sb-readquest-test-auth-token'))).toBeNull();
    await page.reload();
    await expect(page.getByRole('button', { name: 'Login', exact: true })).toBeVisible();
    expect(new URL(page.url()).pathname).toBe(wrongPath);
    await login(page, correctPath);
    await expect(page).toHaveURL(destination);
    expect(state.unexpected).toEqual([]);
  });
}

test('failed role lookup rejects login and allows retry without saving a session', async ({ page }) => {
  const state = await mockSupabase(page, { profileError: true });
  await login(page);
  await expect(page.getByRole('alert')).toContainText('Test profile unavailable');
  await expect(page.getByRole('button', { name: 'Login', exact: true })).toBeEnabled();
  expect(await page.evaluate(() => localStorage.getItem('sb-readquest-test-auth-token'))).toBeNull();
  state.profileError = false;
  await page.getByRole('button', { name: 'Login', exact: true }).click();
  await expect(page).toHaveURL(/\/learn$/);
});

// Reuse the real teacher registration form in all new signup tests.
async function registerTeacher(page: Page) {
  await page.goto('/login/teacher');
  await page.getByRole('button', { name: 'Create an account' }).click();
  await expect(page.locator('form input')).toHaveCount(3);
  await expect(page.getByLabel('Display name', { exact: true })).toHaveValue('Teacher');
  await page.getByLabel('Email', { exact: true }).fill('teacher@example.test');
  await page.getByLabel('Password', { exact: true }).fill('test-password');
  await page.getByRole('button', { name: 'Register', exact: true }).click();
}

test('teacher registration waits for approval, restores pending state, then opens approved dashboard', async ({ page }) => {
  const state = await mockSupabase(page);
  await registerTeacher(page);
  await expect(page).toHaveURL(/\/teacher\/pending$/);
  await expect(page.getByRole('heading', { name: 'Awaiting teacher approval' })).toBeVisible();
  expect(state.signup?.data).toEqual({ display_name: 'Teacher', requested_role: 'teacher' });
  expect(state.learnerFilters).toEqual([]);
  await page.reload();
  await expect(page.getByRole('heading', { name: 'Awaiting teacher approval' })).toBeVisible();
  await page.goto('/learn');
  await expect(page).toHaveURL(/\/teacher\/pending$/);
  expect(state.learnerFilters).toEqual([]);
  // Simulate the administrator approving this account in the protected teachers table.
  state.role = 'teacher';
  await page.getByRole('button', { name: 'Check approval' }).click();
  await expect(page).toHaveURL(/\/teacher$/);
  await expect(page.getByRole('heading', { name: 'Learners (2)' })).toBeVisible();
  await expect(page.locator('.rq-account-name')).toHaveText('Teacher');
  expect(state.unexpected).toEqual([]);
});

test('pending teacher can check status through Teacher Login but cannot use Student Login', async ({ page }) => {
  const state = await mockSupabase(page, { role: 'pending_teacher' });
  await login(page);
  await expect(page.getByRole('alert')).toContainText('Please use Teacher Login.');
  expect(await page.evaluate(() => localStorage.getItem('sb-readquest-test-auth-token'))).toBeNull();
  await login(page, '/login/teacher');
  await expect(page.getByRole('heading', { name: 'Awaiting teacher approval' })).toBeVisible();
  await page.getByRole('button', { name: 'Log out', exact: true }).click();
  await expect(page.getByRole('heading', { name: "Who's Joining The Adventure?" })).toBeVisible();
  expect(state.learnerFilters).toEqual([]);
});

test('teacher email confirmation explains both confirmation and approval', async ({ page }) => {
  await mockSupabase(page, { confirmation: true });
  await registerTeacher(page);
  await expect(page.getByRole('status')).toContainText('Check your email');
  await expect(page.getByRole('status')).toContainText('administrator approval');
  await expect(page.getByRole('button', { name: 'Register', exact: true })).toBeDisabled();
  expect(await page.evaluate(() => localStorage.getItem('sb-readquest-test-auth-token'))).toBeNull();
});

test('missing migration prevents teacher signup before an Auth account is created', async ({ page }) => {
  const state = await mockSupabase(page, { missingTeacherSetup: true });
  await registerTeacher(page);
  await expect(page.getByRole('alert')).toContainText('v0.3.0 database setup');
  expect(state.signup).toBeNull();
  await expect(page.getByRole('button', { name: 'Register', exact: true })).toBeEnabled();
});

test('teacher signup failure displays its error and permits a successful retry', async ({ page }) => {
  const state = await mockSupabase(page, { signupError: true });
  await registerTeacher(page);
  await expect(page.getByRole('alert')).toContainText('Email rate limit exceeded');
  await expect(page.getByRole('button', { name: 'Register', exact: true })).toBeEnabled();
  state.signupError = false;
  await page.getByRole('button', { name: 'Register', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Awaiting teacher approval' })).toBeVisible();
});

