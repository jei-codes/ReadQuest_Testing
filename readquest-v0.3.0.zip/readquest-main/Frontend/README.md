# Frontend team

This folder contains the screens, layouts, React UI state, images and styles.

Use ../README.md to start the app. Install packages and run npm commands from the project ROOT, where package.json is located. Keep Backend beside this folder because the frontend imports its API adapter.

Components call src/services/api.ts. They do not import the Supabase SDK or contain table/RPC queries. The type definitions re-exported by src/types.ts come from Backend/src/models.ts.

Keep your local browser settings in Frontend/.env.local; .env.example is the shareable template.
