import { createReadQuestApi, validateConfig } from '@readquest/backend';
// This is the only frontend file that configures the backend-owned API adapter.
const config = {
  url: import.meta.env.VITE_SUPABASE_URL,
  publishableKey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
};
export const configurationError = validateConfig(config);
export const api = configurationError ? null : createReadQuestApi(config);
