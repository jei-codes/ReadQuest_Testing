import RoleCards from "./RoleCards";

function Wc() {
  return (
    <main
      className="container d-flex flex-column align-items-center justify-content-center py-4"
      style={{ minHeight: "82vh" }}
    >
      <span className="quest-badge mb-2">✨ Welcome to ReadQuest ✨</span>

      <h1 className="quest-title mb-1 text-center">
        Who's Joining The Adventure?
      </h1>

      <p className="quest-subtitle text-center mb-2">
        Pick your role to begin your reading journey! 📖⚔️
      </p>

      <div className="w-100" style={{ maxWidth: "900px" }}>
        <RoleCards />
      </div>
    </main>
  );
}
export default Wc;
