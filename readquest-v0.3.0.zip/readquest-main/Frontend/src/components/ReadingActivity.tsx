import { useEffect, useState } from 'react';
import { api } from '../services/api';
import type { FormEvent } from 'react';
import type { PracticeResponse } from '../types';
import { errorMessage } from '../types';

const question = {
  id: 'practice-cause-001',
  passage:
    'Rain fell all night. By morning, the garden path was muddy. Maya wore her boots to keep her feet dry.',
  questionText: 'Why was the garden path muddy?',
  options: [
    'Maya wore her boots.',
    'Rain fell all night.',
    'Someone watered the flowers.',
  ],
  explanation:
    'The rain made the ground wet and muddy. The rain is the cause, and the muddy path is the effect.',
};

function ReadingActivity({ learnerId }: { learnerId: string }) {
  const [selectedAnswer, setSelectedAnswer] = useState('');
  const [savedResponse, setSavedResponse] = useState<PracticeResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [loadError, setLoadError] = useState('');
  const [saveError, setSaveError] = useState('');

  // When the activity opens, check for an existing response.
  useEffect(() => {
    if (!api) return;
    const backend = api;
    let active = true;

    async function loadResponse() {
      try {
        const data = await backend.practice.getResponse(learnerId, question.id);
        if (!active) return;

        if (data) {
          setSavedResponse(data);
          setSelectedAnswer(data.selected_answer);
        }
      } catch (error) {
        if (active) {
          setLoadError(
            errorMessage(error, 'Unable to load your saved answer.')
          );
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    }

    loadResponse();

    return () => {
      active = false;
    };
  }, [learnerId]);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!api) return;

    if (
      selectedAnswer === '' ||
      saving ||
      savedResponse ||
      loading ||
      loadError
    ) {
      return;
    }

    setSaving(true);
    setSaveError('');

    try {
      // Send only the selected answer.
      // The database identifies the learner and checks correctness.
      const data = await api.practice.submitMiniAnswer(selectedAnswer);

      setSavedResponse(data);
      setSelectedAnswer(data.selected_answer);
    } catch (error) {
      setSaveError(
        errorMessage(error, 'Unable to confirm that your answer was saved.')
      );
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return <p role="status">Checking your saved answer...</p>;
  }

  if (loadError) {
    return (
      <section className="rq-panel rq-reading">
        <p role="alert">Could not load your answer: {loadError}</p>
        <p>Please refresh the page to try again.</p>
      </section>
    );
  }

  return (
    <section className="rq-panel rq-reading">
      <h2>Mini ReadQuest: The Muddy Path</h2>
      <p>Skill: Cause and effect</p>

      <h3>Read the passage</h3>
      <p className="rq-passage">{question.passage}</p>

      <form onSubmit={handleSubmit}>
        <fieldset disabled={saving || savedResponse !== null}>
          <legend>{question.questionText}</legend>

          {question.options.map((option) => (
            <p key={option}>
              <label>
                <input
                  type="radio"
                  name="reading-answer"
                  value={option}
                  checked={selectedAnswer === option}
                  onChange={(event) =>
                    setSelectedAnswer(event.target.value)
                  }
                  required
                />
                {' '}
                {option}
              </label>
            </p>
          ))}

          <button
            type="submit"
            disabled={selectedAnswer === ''}
          >
            {saving ? 'Saving...' : 'Submit answer'}
          </button>
        </fieldset>
      </form>

      {saveError && (
        <p role="alert">
          Could not confirm saving: {saveError}
          {' '}You can submit again; your first saved answer will be kept.
        </p>
      )}

      <div role="status">
        {savedResponse && (
          <>
            <h3>
              {savedResponse.is_correct
                ? 'Correct!'
                : 'Let’s review the answer.'}
            </h3>
            <p>Your answer: {savedResponse.selected_answer}</p>
            <p>{question.explanation}</p>
            <p>Your first answer is saved.</p>
          </>
        )}
      </div>
    </section>
  );
}

export default ReadingActivity;



