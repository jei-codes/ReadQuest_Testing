import { useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { Link } from 'react-router';
import { api } from '../services/api';
import { errorMessage } from '../types';

function Login({ role }: { role: 'Teacher' | 'Student' }) {
  const [isRegister, setIsRegister] = useState(false);
  // Teachers can keep the requested default name or enter a display name for their application.
  const [displayName, setDisplayName] = useState(role === 'Teacher' ? 'Teacher' : '');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [finished, setFinished] = useState(false);
  const [message, setMessage] = useState('');
  const [hasError, setHasError] = useState(false);
  const submitting = useRef(false);
  const registering = isRegister;

  function toggleMode() {
    setIsRegister(!isRegister);
    setPassword('');
    setMessage('');
    setHasError(false);
    setFinished(false);
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!api || submitting.current || finished) return;
    const name = displayName.trim();
    if (registering && (name.length < 2 || name.length > 40)) {
      setHasError(true);
      setMessage('Enter a display name with 2 to 40 characters.');
      return;
    }
    submitting.current = true;
    setBusy(true);
    setMessage('');
    setHasError(false);
    try {
      if (registering) {
        // Each registration route uses its own service; teacher signup creates a pending request.
        const input = { displayName: name, email, password,
          redirectTo: `${window.location.origin}/login/${role === 'Teacher' ? 'teacher' : 'student'}` };
        const result = role === 'Teacher'
          ? await api.auth.registerTeacher(input)
          : await api.auth.registerLearner(input);
        setPassword('');
        setFinished(true);
        if (result.needsEmailConfirmation) setMessage(role === 'Teacher'
          ? 'Check your email for a confirmation link, then use Teacher Login. New teacher accounts also need administrator approval. If you already have an account, use the login form.'
          : 'Check your email for a confirmation link, then log in. If you already have an account, use the login form.');
        // Immediate sign-in is handled by useAccount; the database trigger creates the profile.
      } else {
        // Each login form accepts only its matching database role.
        await api.auth.signIn(email, password, role === 'Teacher' ? 'teacher' : 'learner');
        setPassword('');
      }
    } catch (error) {
      setHasError(true);
      setMessage(errorMessage(error, registering ? 'Registration could not be completed.' : 'Unable to sign in.'));
    } finally {
      submitting.current = false;
      setBusy(false);
    }
  }

  return (
    <main className="container d-flex flex-column align-items-center justify-content-center py-4" style={{ minHeight: '80vh' }}>
      <div className={registering ? 'row g-0 auth-panel is-register' : 'row g-0 auth-panel'}>
        <section className="col-12 col-md-6 auth-welcome">
          <h2>Welcome to ReadQuest!</h2>
          <p>{role === 'Teacher' ? 'Sign in to follow your learners’ reading adventures.' : 'A new reading adventure is waiting for you.'}</p>
          <div className="d-flex align-items-center gap-2 mt-3 flex-wrap">
            <Link to="/" className="btn btn-outline-light">← Back</Link>
            <button type="button" className="btn btn-outline-light" disabled={busy} onClick={toggleMode}>
              {registering ? 'Back to Login' : 'Create an account'}
            </button>
          </div>
        </section>
        <section className="col-12 col-md-6 auth-form">
          <h2>{role} {registering ? 'Register' : 'Login'}</h2>
          {role === 'Teacher' && <p className="small">{registering
            ? 'Create your account here. An administrator must approve it before you can view learners and their records.'
            : 'Use your approved teacher account, or create an account to request access.'}</p>}
          <form onSubmit={handleSubmit}>
            <fieldset disabled={busy || finished}>
              <legend className="visually-hidden">{registering ? 'Registration details' : 'Login details'}</legend>
              {registering && <div className="mb-3">
                <label htmlFor="displayName" className="form-label">Display name</label>
                <input id="displayName" name="displayName" type="text" className="form-control" autoComplete="nickname"
                  value={displayName} onChange={(event) => setDisplayName(event.target.value)} minLength={2} maxLength={40} required />
              </div>}
              <div className="mb-3">
                <label htmlFor="email" className="form-label">Email</label>
                <input id="email" name="email" type="email" className="form-control" autoComplete={registering ? 'email' : 'username'}
                  value={email} onChange={(event) => setEmail(event.target.value)} required />
              </div>
              <div className="mb-3">
                <label htmlFor="password" className="form-label">Password</label>
                <input id="password" name="password" type="password" className="form-control" autoComplete={registering ? 'new-password' : 'current-password'}
                  value={password} onChange={(event) => setPassword(event.target.value)} minLength={registering ? 8 : undefined}
                  aria-describedby={registering ? 'password-help' : undefined} required />
                {registering && <p id="password-help" className="small mt-2">Use at least 8 characters.</p>}
              </div>
              <button type="submit" className="btn btn-success w-100 mt-2">
                {busy ? (registering ? 'Creating account...' : 'Signing in...') : (registering ? 'Register' : 'Login')}
              </button>
            </fieldset>
          </form>
          {message && <p role={hasError ? 'alert' : 'status'} className={`mt-3 ${hasError ? 'text-danger' : ''}`}>{message}</p>}
        </section>
      </div>
    </main>
  );
}
export default Login;

