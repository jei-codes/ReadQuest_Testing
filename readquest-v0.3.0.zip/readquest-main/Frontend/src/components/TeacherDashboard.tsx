import { useEffect, useState } from 'react';
import { api } from '../services/api';
import { ROSTER_PAGE_SIZE, RESPONSE_PAGE_SIZE } from '@readquest/backend';
import type { Learner, Teacher, PracticeResponse } from '../types';
import { errorMessage } from '../types';




const skillNames: Record<string, string> = {
  vocabulary: 'Vocabulary', vocabulary_in_context: 'Vocabulary in context',
  main_idea: 'Main idea', supporting_details: 'Supporting details',
  sequencing: 'Sequencing', cause_and_effect: 'Cause and effect', inference: 'Inference',
};

function LearnerRecords({ learner }: { learner: Learner }) {
  const [page, setPage] = useState(0);
  const [records, setRecords] = useState<PracticeResponse[]>([]);
  const [total, setTotal] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!api) return;
    const backend = api;
    let active = true;
    setLoading(true);
    setError('');
    async function loadRecords() {
      try {
        const result = await backend.teachers.getLearnerRecords(learner.id, page);
        if (!active) return;
        setRecords(result.records);
        setTotal(result.total);
        setCorrect(result.correct);
      } catch (error) {
        if (active) setError(errorMessage(error, 'Unable to load learner records.'));
      } finally {
        if (active) setLoading(false);
      }
    }
    loadRecords();
    return () => { active = false; };
  }, [learner.id, page]);

  return (
    <section className="rq-panel" aria-labelledby="learner-records-title">
      <p className="rq-eyebrow">{learner.learner_code}</p>
      <h2 id="learner-records-title">{learner.display_name}'s records</h2>
      <p className="rq-muted">Learner ID: {learner.id}</p>
      {loading ? <p role="status">Loading saved answers...</p> : error ? (
        <p role="alert">{error} Use Refresh records to try again.</p>
      ) : (
        <>
          <div className="rq-metrics">
            <div><strong>{total}</strong><span>Saved first answers</span></div>
            <div><strong>{correct}</strong><span>Correct first answers</span></div>
            <div><strong>{total ? `${Math.round(correct / total * 100)}%` : '—'}</strong>
              <span>First-answer accuracy</span></div>
          </div>
          <p className="rq-muted">Accuracy describes these saved answers; it is not a mastery estimate.</p>
          {!total ? <p className="rq-empty">This learner has not saved a practice answer yet.</p> : (
            <>
              <div className="rq-table-scroll" tabIndex={0} role="region" aria-label="Saved answers">
                <table className="rq-records">
                  <caption>Practice response history</caption>
                  <thead><tr><th scope="col">Question</th><th scope="col">Skill</th>
                    <th scope="col">First answer</th><th scope="col">Result</th><th scope="col">Submitted</th>
                  </tr></thead>
                  <tbody>{records.map((record) => (
                    <tr key={record.question_id}>
                      <td>{record.question_id}</td>
                      <td>{skillNames[record.skill] ?? record.skill.replaceAll('_', ' ')}</td>
                      <td>{record.selected_answer}</td>
                      <td><span className={record.is_correct ? 'rq-correct' : 'rq-review'}>
                        {record.is_correct ? 'Correct' : 'Incorrect'}
                      </span></td>
                      <td><time dateTime={record.created_at}>
                        {new Date(record.created_at).toLocaleString()}
                      </time></td>
                    </tr>
                  ))}</tbody>
                </table>
              </div>
              <nav className="rq-pagination" aria-label="Response pages">
                <button type="button" disabled={page === 0} onClick={() => setPage(page - 1)}>Previous</button>
                <span>Page {page + 1} of {Math.max(1, Math.ceil(total / RESPONSE_PAGE_SIZE))}</span>
                <button type="button" disabled={(page + 1) * RESPONSE_PAGE_SIZE >= total}
                  onClick={() => setPage(page + 1)}>Next</button>
              </nav>
            </>
          )}
        </>
      )}
    </section>
  );
}

function TeacherDashboard({ teacher }: { teacher: Teacher }) {
  const [learners, setLearners] = useState<Learner[]>([]);
  const [selected, setSelected] = useState<Learner | null>(null);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const [refresh, setRefresh] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!api) return;
    const backend = api;
    let active = true;
    setLoading(true);
    setError('');
    setSelected(null);
    async function loadLearners() {
      try {
        const result = await backend.teachers.listLearners(teacher.id, page);
        if (!active) return;
        setLearners(result.learners);
        setTotal(result.total);
        setSelected(result.learners[0] ?? null);
      } catch (error) {
        if (active) setError(errorMessage(error, 'Unable to load learners.'));
      } finally {
        if (active) setLoading(false);
      }
    }
    loadLearners();
    return () => { active = false; };
  }, [teacher.id, page, refresh]);

  return (
    <div>
      <div className="rq-toolbar">
        <div><h2>Welcome, {teacher.display_name}</h2><p>Review all learners' reading practice.</p></div>
        <button type="button" disabled={loading} onClick={() => setRefresh((value) => value + 1)}>
          Refresh records
        </button>
      </div>
      {loading ? <p role="status">Loading learners...</p> : error ? (
        <p role="alert" className="rq-notice">{error} Use Refresh records to try again.</p>
      ) : !total ? (
        <section className="rq-panel"><h2>No learners registered yet</h2>
          <p>New learners will appear here after registration. Use Refresh records to check again.</p></section>
      ) : (
        <div className="rq-dashboard-grid">
          <aside className="rq-panel" aria-label="Learners">
            <h2>Learners ({total})</h2>
            <ul className="rq-roster">{learners.map((learner) => (
              <li key={learner.id}><button type="button"
                className={selected?.id === learner.id ? 'rq-selected' : ''}
                aria-pressed={selected?.id === learner.id}
                onClick={() => setSelected(learner)}>
                <strong>{learner.display_name}</strong><span>{learner.learner_code}</span>
              </button></li>
            ))}</ul>
            <nav className="rq-pagination" aria-label="Learner pages">
              <button type="button" disabled={page === 0} onClick={() => setPage(page - 1)}>Previous</button>
              <span>{page + 1} / {Math.max(1, Math.ceil(total / ROSTER_PAGE_SIZE))}</span>
              <button type="button" disabled={(page + 1) * ROSTER_PAGE_SIZE >= total}
                onClick={() => setPage(page + 1)}>Next</button>
            </nav>
          </aside>
          {selected && <LearnerRecords key={`${selected.id}-${refresh}`} learner={selected} />}
        </div>
      )}
    </div>
  );
}

export default TeacherDashboard;




