import { Link } from 'react-router';
import Logo from '../assets/Logo.png';

type Props = { displayName?: string; signedIn: boolean; busy: boolean; onLogout: () => void };
function Navbar({ displayName, signedIn, busy, onLogout }: Props) {
  return (
    <header className="navbar px-4 py-3 border-bottom gap-3">
      <Link to="/" className="navbar-brand storybrand d-flex align-items-center gap-2">
        <img src={Logo} alt="" height={60} />ReadQuest
      </Link>
      {signedIn && <div className="d-flex align-items-center gap-3 flex-wrap">
        {displayName && <span className="rq-account-name">{displayName}</span>}
        <button type="button" className="btn btn-outline-success" disabled={busy} onClick={onLogout}>
          {busy ? 'Logging out...' : 'Log out'}
        </button>
      </div>}
    </header>
  );
}
export default Navbar;
