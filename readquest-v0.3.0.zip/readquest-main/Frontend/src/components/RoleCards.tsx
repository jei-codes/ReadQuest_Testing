import knight from "../assets/knight.png";
import Teacher from "../assets/Teacher.png";
import { Link } from "react-router";

function RoleCards() {
  return (
    <div className="row g-4 mt-2">
      <div className="col-12 col-md-6">
        <Link
          to="/login/student"
          className="card role-card w-100 text-center p-4 text-decoration-none"
        >
          <span className="h2 role-title">Student</span>
          <span>Begin your reading adventure.</span>
          <img src={knight} alt="" height={120} className="mt-3 mx-auto" />
        </Link>
      </div>

      <div className="col-12 col-md-6">
        <Link
          to="/login/teacher"
          className="card role-card w-100 text-center p-4 text-decoration-none"
        >
          <span className="h2 role-title">Teacher</span>
          <span>Guide your readers.</span>
          <img src={Teacher} alt="" height={120} className="mt-3 mx-auto" />
        </Link>
      </div>
    </div>
  );
}

export default RoleCards;
