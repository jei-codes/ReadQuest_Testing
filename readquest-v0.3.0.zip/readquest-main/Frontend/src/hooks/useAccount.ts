import { useEffect, useState } from 'react';
import { api } from '../services/api';
import { errorMessage } from '../types';
import type { Account, SignedInUser } from '../types';

type Result = { userId: string; account: Account | null; error: string };
export function useAccount() {
  const [auth, setAuth] = useState<{ ready: boolean; user: SignedInUser | null; error: string }>({ ready: false, user: null, error: '' });
  const [result, setResult] = useState<Result | null>(null);
  const [attempt, setAttempt] = useState(0);
  const userId = auth.user?.id;

  useEffect(() => {
    if (!api) return;
    let active = true;
    let receivedEvent = false;
    const unsubscribe = api.auth.onSessionChange((user) => {
      if (!active) return;
      receivedEvent = true;
      setAuth({ ready: true, user, error: '' });
      if (!user) setResult(null);
    });
    api.auth.getCurrentUser().then((user) => {
      if (active && !receivedEvent) setAuth({ ready: true, user, error: '' });
    }).catch((error: unknown) => {
      if (active && !receivedEvent) setAuth({ ready: true, user: null,
        error: errorMessage(error, 'Unable to restore your login. Please reload the page.') });
    });
    return () => { active = false; unsubscribe(); };
  }, []);

  useEffect(() => {
    if (!userId || !api) return;
    let active = true;
    api.accounts.getAccount(userId).then((account) => {
      if (active) setResult({ userId, account, error: '' });
    }).catch((error: unknown) => {
      if (active) setResult({ userId, account: null, error: errorMessage(error, 'Unable to load your account.') });
    });
    return () => { active = false; };
  }, [userId, attempt]);

  const current = userId && result?.userId === userId ? result : null;
  return {
    userId,
    loading: !auth.ready || (!!userId && !current),
    account: current?.account ?? null,
    error: auth.error || current?.error || '',
    retry: () => { setResult(null); setAttempt((value) => value + 1); },
  };
}
