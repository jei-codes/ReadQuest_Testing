import './App.css';
import './Dashboard.css';
import { useState } from 'react';
import Navbar from './components/navbar';
import Wc from './components/welcome';
import { Routes, Route, Navigate } from 'react-router';
import Login from './components/LoginPanel';
import ReadingActivity from './components/ReadingActivity';
import TeacherDashboard from './components/TeacherDashboard';
import { useAccount } from './hooks/useAccount';
import { configurationError, api } from './services/api';
import { errorMessage } from './types';

function App() {
  const { userId, loading, account, error, retry } = useAccount();
  const [signingOut, setSigningOut] = useState(false);
  const [logoutError, setLogoutError] = useState('');

  async function handleLogout() {
    if (!api || signingOut) return;
    setSigningOut(true);
    setLogoutError('');
    try {
      await api.auth.signOut();
    } catch (error) {
      setLogoutError(errorMessage(error, 'Unable to log out. Please try again.'));
    } finally { setSigningOut(false); }
  }

  let content;
  if (configurationError) content = <main className="container py-5"><h1>Connect ReadQuest</h1><p role="alert">{configurationError}</p></main>;
  else if (error) content = <main className="container py-5"><section className="rq-panel">
    <h1>We could not load your account</h1><p role="alert">{error}</p>
    {userId ? <button className="btn btn-success" onClick={retry}>Try again</button> : <button className="btn btn-success" onClick={() => window.location.reload()}>Reload page</button>}
  </section></main>;
  else if (loading) content = <main className="container py-5"><p role="status">Checking your saved login...</p></main>;
  // Pending teachers can refresh their approval status and log out, but no learner data is loaded.
  else if (account?.role === 'pending_teacher') content = <Routes>
    <Route path="/teacher/pending" element={<main className="container rq-shell py-4">
      <section className="rq-panel">
        <h1>Awaiting teacher approval</h1>
        <p>Hello, {account.profile.display_name}. Your registration has been received.</p>
        <p>Contact your project administrator to approve your teacher account. Learners and their records will become available after approval.</p>
        <button type="button" className="btn btn-success" onClick={retry}>Check approval</button>
      </section>
    </main>} />
    <Route path="*" element={<Navigate to="/teacher/pending" replace />} />
  </Routes>;
  else if (account) {
    const destination = account.role === 'teacher' ? '/teacher' : '/learn';
    content = <Routes>
      <Route path={destination} element={<main className="container rq-shell py-4" key={userId}>
        {account.role === 'teacher' ? <TeacherDashboard teacher={account.profile} /> : <>
          <header className="mb-4"><span className="quest-badge">Your reading adventure</span>
            <h1 className="quest-title mt-3">Welcome, {account.profile.display_name}!</h1>
            <p>Learner code: <strong>{account.profile.learner_code}</strong></p>
          </header>
          <ReadingActivity learnerId={account.profile.id} />
        </>}
      </main>} />
      <Route path="*" element={<Navigate to={destination} replace />} />
    </Routes>;
  } else content = <Routes>
    <Route path="/" element={<Wc />} />
    <Route path="/login/student" element={<Login key="student" role="Student" />} />
    <Route path="/login/teacher" element={<Login key="teacher" role="Teacher" />} />
    <Route path="/teacher" element={<Navigate to="/login/teacher" replace />} />
    <Route path="/learn" element={<Navigate to="/login/student" replace />} />
    <Route path="*" element={<Navigate to="/" replace />} />
  </Routes>;

  return <>
    <Navbar displayName={account?.profile.display_name} signedIn={!!userId} busy={signingOut} onLogout={handleLogout} />
    {logoutError && <p role="alert" className="container mt-3 text-danger">{logoutError}</p>}
    {content}
  </>;
}
export default App;

