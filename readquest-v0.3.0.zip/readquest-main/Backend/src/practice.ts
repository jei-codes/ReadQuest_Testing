import type { SupabaseClient } from '@supabase/supabase-js';
import type { PracticeResponse } from './models';
export function practiceService(client: SupabaseClient) {
  return {
    async getResponse(learnerId: string, questionId: string): Promise<PracticeResponse | null> {
      const { data, error } = await client.from('practice_responses')
        .select('learner_id, question_id, selected_answer, is_correct, skill, created_at')
        .eq('learner_id', learnerId).eq('question_id', questionId).maybeSingle<PracticeResponse>();
      if (error) throw error;
      return data;
    },
    async submitMiniAnswer(selectedAnswer: string): Promise<PracticeResponse> {
      // Only the selected answer leaves the browser. The Supabase RPC validates
      // the signed-in learner, grades this sample question and keeps the first answer.
      const { data, error } = await client.rpc('submit_mini_readquest_answer', { p_answer: selectedAnswer });
      if (error) throw error;
      if (!data) throw new Error('No saved response was returned.');
      return data as PracticeResponse;
    },
  };
}
