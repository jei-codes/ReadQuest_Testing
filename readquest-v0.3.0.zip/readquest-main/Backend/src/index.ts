import { createConnection } from './client';
import type { BackendConfig } from './client';
import { authService } from './auth';
import { accountService } from './accounts';
import { practiceService } from './practice';
import { teacherService } from './teachers';
export { validateConfig } from './client';
export type { BackendConfig } from './client';
export type { SignedInUser, RegistrationInput } from './auth';
export * from './models';
export { ROSTER_PAGE_SIZE, RESPONSE_PAGE_SIZE } from './teachers';

// Backend-owned browser adapter, not a privileged server. Never add server keys.
export function createReadQuestApi(config: BackendConfig) {
  const client = createConnection(config);
  return {
    // Role checks use a temporary session; accepted logins use the shared app connection.
    auth: authService(client, () => createConnection(config, true)),
    accounts: accountService(client),
    practice: practiceService(client),
    teachers: teacherService(client),
  };
}
