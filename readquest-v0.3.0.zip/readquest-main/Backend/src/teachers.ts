import type { SupabaseClient } from '@supabase/supabase-js';
import type { Learner, PracticeResponse } from './models';
export const ROSTER_PAGE_SIZE = 25;
export const RESPONSE_PAGE_SIZE = 20;
export function teacherService(client: SupabaseClient) {
  return {
    async listLearners(teacherId: string, page: number): Promise<{ learners: Learner[]; total: number }> {
      const from = Math.max(0, page) * ROSTER_PAGE_SIZE;
      // RLS checks teacher approval. This client-side filter only excludes their
      // own auto-created learner row from the roster.
      const { data, count, error } = await client.from('Learners')
        .select('id, learner_code, display_name', { count: 'exact' })
        .neq('id', teacherId).order('created_at').order('id')
        .range(from, from + ROSTER_PAGE_SIZE - 1);
      if (error) throw error;
      return { learners: data ?? [], total: count ?? 0 };
    },
    async getLearnerRecords(learnerId: string, page: number): Promise<{ records: PracticeResponse[]; total: number; correct: number }> {
      const from = Math.max(0, page) * RESPONSE_PAGE_SIZE;
      const [responses, correct] = await Promise.all([
        client.from('practice_responses')
          .select('learner_id, question_id, selected_answer, is_correct, skill, created_at', { count: 'exact' })
          .eq('learner_id', learnerId).order('created_at', { ascending: false }).order('question_id')
          .range(from, from + RESPONSE_PAGE_SIZE - 1),
        client.from('practice_responses').select('question_id', { count: 'exact', head: true })
          .eq('learner_id', learnerId).eq('is_correct', true),
      ]);
      if (responses.error) throw responses.error;
      if (correct.error) throw correct.error;
      return { records: responses.data ?? [], total: responses.count ?? 0, correct: correct.count ?? 0 };
    },
  };
}
