import type { SupabaseClient } from '@supabase/supabase-js';
import { accountService } from './accounts';
export type SignedInUser = { id: string };
export type RegistrationInput = { displayName: string; email: string; password: string; redirectTo: string };

export function authService(client: SupabaseClient, createLoginConnection: () => SupabaseClient) {
  return {
    async signIn(email: string, password: string, expectedRole: 'teacher' | 'learner'): Promise<void> {
      // Authenticate privately first, so the app cannot redirect before role validation.
      const loginClient = createLoginConnection();
      try {
        const { data, error } = await loginClient.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
        if (!data.session) throw new Error('Unable to start your login. Please try again.');

        // Database profiles decide the role. Form choices and user metadata cannot grant teacher access.
        // Teacher approval is checked first, including accounts that also have a learner profile.
        const account = await accountService(loginClient).getAccount(data.user.id);
        // Pending teachers may use Teacher Login to check approval, but never Student Login.
        const loginRole = account.role === 'pending_teacher' ? 'teacher' : account.role;
        if (loginRole !== expectedRole) {
          throw new Error(account.role === 'learner'
            ? 'This is a student account. Please use Student Login.'
            : 'This is a teacher account. Please use Teacher Login.');
        }

        // Only a matching account becomes the app's saved session.
        // Supabase RLS still enforces database permissions independently of this form check.
        const { error: sessionError } = await client.auth.setSession({
          access_token: data.session.access_token,
          refresh_token: data.session.refresh_token,
        });
        if (sessionError) throw sessionError;
      } catch (error) {
        // Revoke a rejected temporary login. Even if the request fails, it was never saved locally.
        try { await loginClient.auth.signOut({ scope: 'local' }); } catch { /* Preserve the original login error. */ }
        throw error;
      }
    },
    async registerTeacher(input: RegistrationInput): Promise<{ needsEmailConfirmation: boolean }> {
      const displayName = input.displayName.trim();
      if (displayName.length < 2 || displayName.length > 40) throw new Error('Enter a display name with 2 to 40 characters.');
      if (input.password.length < 8) throw new Error('Use at least 8 characters for your password.');

      // Stop before creating an account if the administrator has not installed the signup migration.
      const { data: version, error: setupError } = await client.rpc('readquest_teacher_registration_version');
      if (setupError || version !== '0.3.0') {
        throw new Error('Teacher registration is not ready yet. Ask the administrator to complete the v0.3.0 database setup.');
      }
      const { data, error } = await client.auth.signUp({
        email: input.email.trim(), password: input.password,
        options: {
          // This requests approval only. The database never inserts an approved teacher from this value.
          data: { display_name: displayName, requested_role: 'teacher' },
          emailRedirectTo: input.redirectTo,
        },
      });
      if (error) throw error;
      return { needsEmailConfirmation: !data.session };
    },
    async registerLearner(input: RegistrationInput): Promise<{ needsEmailConfirmation: boolean }> {
      const displayName = input.displayName.trim();
      if (displayName.length < 2 || displayName.length > 40) throw new Error('Enter a display name with 2 to 40 characters.');
      if (input.password.length < 8) throw new Error('Use at least 8 characters for your password.');
      const { data, error } = await client.auth.signUp({
        email: input.email.trim(), password: input.password,
        options: { data: { display_name: displayName }, emailRedirectTo: input.redirectTo },
      });
      if (error) throw error;
      return { needsEmailConfirmation: !data.session };
    },
    async signOut(): Promise<void> {
      const { error } = await client.auth.signOut({ scope: 'local' });
      if (error) throw error;
    },
    async getCurrentUser(): Promise<SignedInUser | null> {
      // Restores browser session for UI only. Supabase RLS remains the access boundary.
      const { data, error } = await client.auth.getSession();
      if (error) throw error;
      return data.session ? { id: data.session.user.id } : null;
    },
    onSessionChange(callback: (user: SignedInUser | null) => void): () => void {
      const { data: { subscription } } = client.auth.onAuthStateChange((_event, session) => {
        callback(session ? { id: session.user.id } : null);
      });
      return () => subscription.unsubscribe();
    },
  };
}
