import { createClient } from '@supabase/supabase-js';
// Give every temporary attempt its own key so retries cannot share auth state.
let loginConnectionId = 0;
export type BackendConfig = { url?: string; publishableKey?: string };
export function validateConfig({ url, publishableKey }: BackendConfig): string {
  try {
    if (!url?.trim() || !publishableKey?.trim()) throw new Error('Missing settings');
    if (!['http:', 'https:'].includes(new URL(url.trim()).protocol)) throw new Error('Invalid URL');
    if (publishableKey.trim().startsWith('sb_secret_')) throw new Error('Server secret');
    return '';
  } catch {
    return 'Add your Supabase project URL and publishable key to Frontend/.env.local, then restart the development server.';
  }
}
export function createConnection(config: BackendConfig, temporary = false) {
  const problem = validateConfig(config);
  if (problem) throw new Error(problem);
  // A temporary login connection keeps its session in memory until the role is checked.
  // Its separate storage key prevents login events from reaching the main app early.
  return createClient(config.url!.trim(), config.publishableKey!.trim(), temporary ? {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
      detectSessionInUrl: false,
      storageKey: `readquest-login-check-${++loginConnectionId}`,
    },
  } : undefined);
}
