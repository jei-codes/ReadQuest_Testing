export type Learner = { id: string; display_name: string; learner_code: string };
export type Teacher = { id: string; display_name: string };
export type Account =
  | { role: 'teacher'; profile: Teacher }
  // Registration requests have no teacher permissions until an administrator approves them.
  | { role: 'pending_teacher'; profile: Teacher }
  | { role: 'learner'; profile: Learner };
export type PracticeResponse = {
  learner_id: string;
  question_id: string;
  selected_answer: string;
  is_correct: boolean;
  skill: string;
  created_at: string;
};
export function errorMessage(error: unknown, fallback: string): string {
  return typeof error === 'object' && error !== null && 'message' in error
    && typeof error.message === 'string' ? error.message : fallback;
}
