import type { SupabaseClient } from '@supabase/supabase-js';
import type { Account, Learner, Teacher } from './models';
export function accountService(client: SupabaseClient) {
  return {
    async getAccount(userId: string): Promise<Account> {
      const { data: teacher, error: teacherError } = await client.from('teachers')
        .select('id, display_name').eq('id', userId).maybeSingle<Teacher>();
      if (teacherError) throw teacherError;
      // Use the requested display name consistently in the dashboard and navigation.
      // This is a presentation label; it does not change teacher approval or database records.
      if (teacher) return { role: 'teacher', profile: { ...teacher, display_name: 'Teacher' } };
      // A protected request row records pending status; editable signup metadata never approves access.
      const { data: request, error: requestError } = await client.from('teacher_registration_requests')
        .select('id, display_name').eq('id', userId).maybeSingle<Teacher>();
      if (requestError) throw requestError;
      if (request) return { role: 'pending_teacher', profile: request };
      const { data: learner, error } = await client.from('Learners')
        .select('id, display_name, learner_code').eq('id', userId).maybeSingle<Learner>();
      if (error) throw error;
      if (!learner) throw new Error('Your account is signed in, but its learner profile is missing. Ask the project administrator to check the signup trigger.');
      return { role: 'learner', profile: learner };
    },
  };
}
