-- ReadQuest v0.3.0: run the entire file in Supabase SQL Editor as administrator.
-- Requires the existing teachers, Learners, and learner signup trigger from ReadQuest.
-- This adds a request workflow. It never grants teacher access during public signup.
begin;

create table if not exists public.teacher_registration_requests (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (length(trim(display_name)) between 2 and 40),
  created_at timestamptz not null default now()
);

-- Applicants can read their own request only. They cannot approve or edit it.
alter table public.teacher_registration_requests enable row level security;
revoke all on public.teacher_registration_requests from public, anon, authenticated;
grant select on public.teacher_registration_requests to authenticated;
drop policy if exists "Applicants read own teacher request" on public.teacher_registration_requests;
create policy "Applicants read own teacher request"
on public.teacher_registration_requests for select to authenticated
using (id = (select auth.uid()));

-- Keep approvals administrator-only, even if a browser tries to insert a teacher directly.
alter table public.teachers enable row level security;
revoke insert, update, delete, truncate, references, trigger
on public.teachers from public, anon, authenticated;

-- Record the request during account creation, whether email confirmation is on or off.
-- Later edits to user metadata cannot create or approve a request.
create or replace function public.readquest_capture_teacher_request()
returns trigger language plpgsql security definer set search_path = ''
as $$
declare
  v_name text;
begin
  if new.raw_user_meta_data ->> 'requested_role' = 'teacher' then
    v_name := trim(coalesce(new.raw_user_meta_data ->> 'display_name', 'Teacher'));
    if length(v_name) not between 2 and 40 then v_name := 'Teacher'; end if;
    insert into public.teacher_registration_requests(id, display_name)
    values (new.id, v_name) on conflict (id) do nothing;
  end if;
  return new;
end;
$$;

revoke all on function public.readquest_capture_teacher_request() from public, anon, authenticated;
drop trigger if exists readquest_capture_teacher_request_after_signup on auth.users;
create trigger readquest_capture_teacher_request_after_signup
after insert on auth.users for each row
execute function public.readquest_capture_teacher_request();

-- Preserve the existing learner signup function and its code sequence.
-- Skip its learner insert for teacher applicants so they do not appear in the student roster.
-- Reading both the request and signup metadata makes this independent of trigger execution order.
create or replace function public.readquest_skip_teacher_learner_profile()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  if exists (select 1 from public.teacher_registration_requests where id = new.id)
    or exists (select 1 from public.teachers where id = new.id)
    or exists (
      select 1 from auth.users where id = new.id
        and raw_user_meta_data ->> 'requested_role' = 'teacher'
    ) then
    return null;
  end if;
  return new;
end;
$$;

revoke all on function public.readquest_skip_teacher_learner_profile() from public, anon, authenticated;
drop trigger if exists readquest_skip_teacher_learner_profile on public."Learners";
create trigger readquest_skip_teacher_learner_profile
before insert on public."Learners" for each row
execute function public.readquest_skip_teacher_learner_profile();

-- A public readiness check returns a version only, with no account or learner information.
-- The frontend checks this before sending a teacher signup request.
create or replace function public.readquest_teacher_registration_version()
returns text language sql stable security invoker set search_path = ''
as $$ select '0.3.0'::text; $$;
revoke all on function public.readquest_teacher_registration_version() from public;
grant execute on function public.readquest_teacher_registration_version() to anon, authenticated;

commit;
