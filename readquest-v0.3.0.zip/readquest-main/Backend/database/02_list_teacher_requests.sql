-- Administrator-only review: run in Supabase SQL Editor.
-- The request table deliberately keeps email addresses in Auth instead of duplicating them.
select r.id, u.email, r.display_name, r.created_at,
  case when t.id is null then 'Awaiting approval' else 'Approved' end as approval_status,
  u.email_confirmed_at
from public.teacher_registration_requests as r
join auth.users as u on u.id = r.id
left join public.teachers as t on t.id = r.id
order by r.created_at desc;
