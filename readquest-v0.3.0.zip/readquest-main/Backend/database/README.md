# Supabase database source

## v0.3.0 teacher registration (required)

Run 01_teacher_registration_v0.3.0.sql as administrator before starting v0.3.0. It adds protected teacher requests and two triggers, while preserving the existing learner signup function and code sequence. Read ../../TEACHER_REGISTRATION.md first. Use 02_list_teacher_requests.sql to review applicants and 03_approve_registered_teacher.sql to approve one confirmed applicant after editing its email placeholder.

The scripts have been tested against an isolated PostgreSQL fixture representing the documented ReadQuest setup, not your live project's current schema. Existing tables and teacher read policies must already be installed. No live SQL has been executed by this update.

## Existing project background

The original readquest-github-upload.zip contains a React app and connection code, not an export of the live Supabase database. Its deployed tables, trigger definitions, RLS policies, permissions and functions remain in your Supabase project.

Required existing objects:
- public."Learners" with id, learner_code, display_name and created_at.
- public.teachers with id, display_name and created_at.
- public.practice_responses with learner_id, question_id, selected_answer, is_correct, skill and created_at.
- Signup trigger on auth.users that creates a learner profile and its learner code.
- public.submit_mini_readquest_answer(text) that authenticates the caller, validates options, grades the sample question and preserves the first response.
- Own-record RLS policies for learners and all-learner read policies for approved teachers.

check_existing_setup.sql is a read-only inventory. It does not create accounts, reset sequences or change permissions.

export_definitions.sql is also read-only. Run it as the administrator in Supabase SQL Editor to inspect the actual functions, triggers, columns and policies. Save the results for your team's reference before making SQL changes. These query results are NOT a full database backup or a complete runnable migration; they omit items such as constraint definitions, grants and sequence state. Use a proper schema export when setting up another Supabase project.

The folder separation does not require any of these SQL scripts to be run. Continue using the current Supabase project and existing teacher approvals.
