-- Run in Supabase SQL Editor as administrator, after reviewing the applicant.
-- Change ONLY the email below to the teacher account you want to approve.
-- Approval grants access to all learner records under your existing teacher policies.
begin;
do $$
declare
  v_email text := 'REPLACE_WITH_REGISTERED_TEACHER_EMAIL';
  v_id uuid;
  v_name text;
begin
  if v_email = 'REPLACE_WITH_REGISTERED_TEACHER_EMAIL' then
    raise exception 'Replace the email placeholder with the teacher applicant email first.';
  end if;

  -- Only an existing, confirmed teacher applicant is eligible for this approval script.
  select u.id, r.display_name into v_id, v_name
  from auth.users as u
  join public.teacher_registration_requests as r on r.id = u.id
  where lower(u.email) = lower(trim(v_email)) and u.email_confirmed_at is not null;
  if v_id is null then
    raise exception 'No confirmed teacher request found. Check the email and any email confirmation requirement.';
  end if;

  -- No password, student records, learner codes or other accounts are changed.
  insert into public.teachers(id, display_name) values (v_id, v_name)
  on conflict (id) do nothing;
end;
$$;
commit;
