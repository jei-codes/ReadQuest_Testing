-- Read-only inspection for the EXISTING ReadQuest Supabase project.
-- Run in SQL Editor as administrator. Does not register accounts or reset codes.
select
  to_regclass('public."Learners"') as learners_table,
  to_regclass('public.teachers') as teachers_table,
  to_regclass('public.practice_responses') as responses_table,
  to_regprocedure('public.submit_mini_readquest_answer(text)') as submit_function;

select tgname as trigger_name, tgenabled as status,
  pg_get_triggerdef(oid) as definition
from pg_trigger
where tgrelid = 'auth.users'::regclass and not tgisinternal;

select tablename, policyname, roles, cmd, qual
from pg_policies
where schemaname = 'public'
  and tablename in ('Learners', 'teachers', 'practice_responses')
order by tablename, policyname;
