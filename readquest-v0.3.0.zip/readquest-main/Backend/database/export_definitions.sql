-- READ ONLY: inspect relevant live definitions before maintaining backend SQL.
-- This is an inventory, NOT a complete schema backup or runnable migration.
select n.nspname as schema_name, p.proname as function_name,
  pg_get_functiondef(p.oid) as definition
from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where (n.nspname = 'public' and p.proname in
  ('create_readquest_learner', 'submit_mini_readquest_answer'))
  or (n.nspname = 'private' and p.proname = 'readquest_teacher_can_read_learner');

select tgname as trigger_name, pg_get_triggerdef(oid) as definition
from pg_trigger where tgrelid = 'auth.users'::regclass and not tgisinternal;

select table_name, column_name, data_type, is_nullable, column_default
from information_schema.columns
where table_schema = 'public' and table_name in ('Learners', 'teachers', 'practice_responses')
order by table_name, ordinal_position;

select tablename, policyname, permissive, roles, cmd, qual, with_check
from pg_policies where schemaname = 'public'
  and tablename in ('Learners', 'teachers', 'practice_responses')
order by tablename, policyname;
