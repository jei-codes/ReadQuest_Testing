# Backend team

src/ owns ReadQuest's Supabase connection, authentication and data-access services. It has no React components. The frontend imports the public methods and types from src/index.ts using the @readquest/backend alias.

These modules run in the browser. They connect to the REAL backend hosted by Supabase. Never put a database password, secret/service-role key or administrator-only action in src/.

Database permissions, account approval, answer grading and first-answer enforcement remain in Supabase. See database/README.md for the hosted definitions missing from the original ZIP. Do not run any database reset for this reorganization.

There is one package.json in the project root. From that root, run npm.cmd ci, npm.cmd run dev, npm.cmd run build and npm.cmd run test:e2e.
