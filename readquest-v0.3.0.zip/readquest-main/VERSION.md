# ReadQuest v0.3.0

Release date: October 14, 2026 (Asia/Singapore)

Release name: Teacher registration with administrator approval

The version is recorded in the project files and download filename only. It is not displayed inside the game.

See CHANGELOG.md for release history and TEACHER_REGISTRATION.md for this release's required database setup and approval instructions. LOGIN_UPDATE.md describes the earlier v0.2.0 login changes.

## Version convention for future updates

- Small fixes: increase the last number, for example 0.2.0 to 0.2.1.
- New features: increase the middle number, for example 0.2.1 to 0.3.0.
- Major changes that require migration: increase the first number, for example 1.0.0 to 2.0.0. Choose the first stable 1.0.0 release together as a team.

For every release, update this file, the root package.json version, both root package versions in package-lock.json, and CHANGELOG.md. Do not change dependency versions just to label a release.

Name the shared source archive readquest-vVERSION.zip, such as readquest-v0.2.0.zip. Keep source filenames and the inner readquest-main folder unchanged so imports and file replacements keep working. Keep previous archives as backups.

Archive source files only. Exclude node_modules, build outputs, test results, local environment files and Git history; include Frontend/.env.example.
