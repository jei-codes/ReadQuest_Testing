# ReadQuest v0.3.0 — teacher registration

Teacher Login now includes Create an account. Registration asks for Display name, Email and Password; the display name starts as Teacher. New accounts wait for administrator approval before accessing any learner records.

## 1. Install the database update first

Open Supabase > SQL Editor > New query. Copy the ENTIRE contents of Backend/database/01_teacher_registration_v0.3.0.sql and run it as the project administrator.

This is required before opening v0.3.0: account loading now reads teacher_registration_requests. The script can be rerun, preserves existing accounts and answers, and does not reset learner codes. Do not replace or rerun your original learner table creation scripts.

The database must already have ReadQuest's Learners, teachers and practice_responses tables, the learner signup trigger, and teacher read policies. The original live schema was not included in the source ZIP. If the setup SQL fails, stop and share the exact error rather than resetting tables.

## 2. Start the app

Extract readquest-v0.3.0.zip. Keep or copy your existing settings into Frontend/.env.local. Open the inner readquest-main folder in VS Code.

```powershell
# Install dependencies when using a newly extracted folder.
npm.cmd ci

# Start the app from the root containing BOTH Frontend and Backend.
npm.cmd run dev
```

The ZIP excludes dependencies and local environment settings. Frontend/.env.example is the template if you need to recreate your local file.

## 3. Register a new teacher

Log out first if another account is already signed in. Open Teacher Login, select Create an account, and enter a display name, a new email and a password of at least eight characters.

If email confirmation is enabled, confirm the email and return to Teacher Login. If confirmation is disabled, the app opens Awaiting teacher approval immediately. Approval and email confirmation are separate requirements. Reusing an existing email does not convert an existing learner into a teacher or create an automatic approval.

The signup writes the display name into Auth metadata, so it can appear in Authentication > Users. The request also saves the name. The approved dashboard retains the Teacher display label requested in v0.2.0.

## 4. Review and approve as administrator

Run Backend/database/02_list_teacher_requests.sql in SQL Editor. It lists the applicant email, display name, confirmation date and approval status.

Open Backend/database/03_approve_registered_teacher.sql. Replace REPLACE_WITH_REGISTERED_TEACHER_EMAIL in the v_email assignment with the exact applicant email. Run the complete script in SQL Editor after reviewing that applicant. The script requires a confirmed account and an existing teacher registration request.

Approval grants this teacher access to ALL learner records under the existing ReadQuest teacher policies. Only the project administrator performs approval; ordinary teacher accounts cannot approve themselves or other teachers from the game.

The teacher can press Check approval on the waiting page, or log in again. The dashboard becomes available after approval. Existing approved teachers do not need to register again.

## What the SQL changes

- A teacher_registration_requests table stores requests. Authenticated applicants can read their own row; browser clients cannot insert, edit or approve rows directly.
- An Auth signup trigger records requests for teacher registrations. The requested_role metadata flag requests review; it never grants permissions.
- A BEFORE INSERT trigger on Learners skips new teacher profiles so they do not appear as students. It leaves normal learner inserts unchanged.
- A public readiness function returns only the setup version, allowing the app to check setup before creating a teacher account.
- The existing teachers table remains the only source of approval. Existing access policies, saved answers and learner code sequence are preserved.

The old learner signup function may allocate a sequence number before the new trigger skips a teacher's learner row. This can leave gaps in learner codes; they remain unique. No sequence reset is needed.

## Verification performed

- Production build and TypeScript checks passed.
- All 17 Chrome browser tests passed with simulated Supabase responses: learner flows, teacher registration, pending restoration, approval refresh, wrong-form rejection, confirmation messaging and error retries.
- Isolated PostgreSQL tests passed: migration reruns, teacher/learner signup routing, own-request row security, pending record access denial, denial of direct self-approval, metadata non-approval, confirmed administrator approval and preservation of student answers.

These checks did not connect to or modify the live Supabase project. After setup, test one new teacher account and one learner account against your project before deploying.

## GitHub upload

Upload extracted source files, including Backend/database and this guide, to an update branch. Do not upload the ZIP, node_modules, dist, test-results or .env.local. Apply the database setup before deploying the v0.3.0 app. Applying this additive migration first remains compatible with the old app's existing logins, but new teacher registration requires v0.3.0.
