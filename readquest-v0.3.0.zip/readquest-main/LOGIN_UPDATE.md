# Login and teacher display update

Student Login now accepts only learner accounts. Teacher Login accepts only approved teacher accounts. Using the wrong form shows which form to use, without saving a browser login or opening a dashboard.

The role is checked using the database profile in a temporary, memory-only session. Only a matching account is transferred to the app's saved session. Teacher approval takes priority when a teacher also has a learner row. Existing Supabase RLS remains responsible for protecting records.

Approved teacher accounts appear as "Teacher" in the dashboard and top bar. This is the app's display label; stored teacher names are unchanged. No SQL migration is needed.

## Changed application files

- Backend/src/client.ts: temporary connection settings.
- Backend/src/auth.ts: login role validation before saving a session.
- Backend/src/accounts.ts: teacher display label.
- Backend/src/index.ts: connects the login service to temporary connections.
- Frontend/src/components/LoginPanel.tsx: tells the service which login form was used.
- Frontend/tests/integration.spec.ts: matching and mismatched login tests, restoration and profile-error cases.
- TEAM_GUIDE.md: updated login API example.

Comments explain the new behavior inside the changed code.

## Apply and try it

Keep your existing Frontend/.env.local. Upload the changed source files to a new GitHub branch, then review the pull request. Run commands from the readquest-main root.

```powershell
# Start the updated application after stopping the old server with Ctrl+C.
npm.cmd run dev
```

Log out of any saved session first. Try a learner account in Teacher Login and a teacher account in Student Login; both should show the appropriate error. Then use each account on the correct form. The teacher dashboard and top bar should display "Teacher".

Previously saved sessions still restore to their database role's dashboard. This change does not revoke existing Supabase sessions or change database policies.
