# ReadQuest team guide

## Frontend teammate

Work in Frontend/src/components, Frontend/src/assets, and the CSS files. You own the welcome screen, role cards, login/registration appearance, passage display, dashboard layout and mobile responsiveness. React state and loading/error messages also stay in Frontend.

To call the backend from a component:

```ts
import { api } from '../services/api';

if (!api) return; // The app shows a setup message when settings are missing.
// Student Login expects 'learner'; Teacher Login expects 'teacher'.
await api.auth.signIn(email, password, 'learner');
```

Keep registration fields as Display name, Email and Password. The service method is registerLearner({ displayName, email, password, redirectTo }). It returns needsEmailConfirmation so the form can show the appropriate message.

## Backend teammate

Work in Backend/src. Supabase queries are centralized here; there are no direct Supabase SDK imports, table queries or RPC calls in frontend screen components.

- auth.ts owns registration metadata and authentication calls.
- accounts.ts owns account/profile selection; the protected teachers table determines teacher status.
- practice.ts owns saved-response loading and calls submit_mini_readquest_answer.
- teachers.ts owns roster pagination, response pagination and counts.
- models.ts owns the shared return types.

Manage tables, triggers, RLS and privileged functions in Supabase. Backend/database contains a read-only check and definition-export queries. The original ZIP did not include database migrations, so first save the real deployed definitions before editing SQL. Do not reset the database or learner-code sequence as part of this folder change.

## How the folders connect

Frontend/src/services/api.ts reads Vite's two public environment values and creates the API adapter exported by Backend/src/index.ts. Vite and TypeScript map @readquest/backend to that source file. Both folders are required for the app to compile. No package publishing or second server is needed.

The UI calls these methods:

- api.auth.registerLearner(input): registration result with needsEmailConfirmation.
- api.auth.registerTeacher(input): checks database setup, submits a teacher approval request through Auth signup, and returns needsEmailConfirmation. It never inserts into teachers directly.
- api.auth.signIn(email, password, expectedRole): verifies the database role before saving the login; expectedRole is 'learner' or 'teacher'. Wrong-form attempts show an error and remain signed out.
- api.auth.signOut(): logs out locally or throws an error.
- api.auth.getCurrentUser(): restores the current user ID or returns null.
- api.auth.onSessionChange(callback): listens for changes and returns an unsubscribe function. Keep callbacks synchronous.
- api.accounts.getAccount(userId): returns a teacher, pending_teacher or learner profile. Pending teachers get only the waiting screen.
- api.practice.getResponse(learnerId, questionId): returns the saved response or null.
- api.practice.submitMiniAnswer(answer): saves through the existing RPC and returns the first saved response.
- api.teachers.listLearners(teacherId, page): returns learners and total; page starts at zero.
- api.teachers.getLearnerRecords(learnerId, page): returns records, total and correct.

Methods throw errors for the UI to display. Error text can be extracted with the shared errorMessage helper. The browser adapter is not a security boundary; Supabase enforces permissions on every database request.

Approved teachers use the display label "Teacher" in the dashboard and navigation. accounts.ts supplies this presentation label without updating stored database names. Teacher approval still comes only from the teachers table.

For v0.3.0, follow TEACHER_REGISTRATION.md before running the app. Registration sends display_name and requested_role=teacher to Auth. This metadata requests review only. The database creates a protected request row; approval is an administrator-only operation in SQL Editor. Existing teachers are not automatically allowed to approve others.

## Working at the same time

1. Both teammates clone the SAME repository and keep both folders locally.
2. Create separate feature branches for each task.
3. Frontend work can usually stay in Frontend; backend data-access work can usually stay in Backend.
4. Agree before renaming a method, changing its return type, changing a database column, or updating root dependencies.
5. Run npm.cmd run build and npm.cmd run test:e2e from the root before requesting review.
6. Review the pull request together, especially when a change crosses the folder boundary.

Never put server secrets in Backend/src. It is browser-bundled. Future server-only logic belongs in Supabase database functions or Edge Functions, with its source tracked separately under Backend once implemented.
