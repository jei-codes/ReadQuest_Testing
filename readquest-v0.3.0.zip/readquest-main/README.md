# ReadQuest — frontend and backend team folders

Current release: **v0.3.0**. See [VERSION.md](VERSION.md) for the version and [CHANGELOG.md](CHANGELOG.md) for what changed. Version labels are kept in files only, not in the game interface.

**Before using v0.3.0, run Backend/database/01_teacher_registration_v0.3.0.sql in Supabase SQL Editor as administrator.** This version reads the new teacher request table during account loading. See [TEACHER_REGISTRATION.md](TEACHER_REGISTRATION.md) for setup and approval steps. Do not run the approval script until you have reviewed an actual teacher applicant.

This project separates the screen code from the Supabase service code while keeping them connected in one repository.

## Start the app

Use the top-level readquest-main folder containing BOTH Frontend and Backend. Open that whole folder in VS Code.

1. Copy Frontend/.env.example to Frontend/.env.local.
2. Put your existing Supabase project URL and publishable key in Frontend/.env.local. Keep your current Supabase project, accounts, policies and answer-saving function.
3. Open a terminal at the top-level readquest-main folder and run:

```powershell
npm.cmd ci
npm.cmd run dev
```

Open the Local URL printed in the terminal. Installation and run commands now belong at the PROJECT ROOT. There is one package.json and one package-lock.json for both teams. Node.js 24 was used for validation.

No local backend server is needed. Supabase hosts authentication, database tables, policies, triggers and the answer-saving function. Frontend/.env.local is kept there because Vite reads the browser app's configuration from Frontend. It contains browser connection values only; never add a secret/service-role key.

## Team folders

```text
readquest-main/
  Frontend/
    src/
      components/          Screens, forms and dashboard layouts
      assets/              Images and artwork
      hooks/useAccount.ts  React loading/session state
      services/api.ts      Connects the UI to Backend using local settings
      App.tsx              Screen routing and page layout
      App.css              Original frontend theme
      Dashboard.css        Dashboard and reading-activity styles
    tests/                 Browser integration tests
    .env.example           Public configuration template
  Backend/
    src/
      client.ts            Supabase connection setup
      auth.ts              Register, sign in, sign out, session events
      accounts.ts          Load approved teacher or learner profile
      practice.ts          Read and submit the saved practice answer
      teachers.ts          Fetch all learners and their records
      models.ts            Shared data types returned to the UI
      index.ts             Public service interface
    database/              Existing-database checks and export instructions
  TEAM_GUIDE.md
  package.json
  package-lock.json
```

Your groupmates can focus on Frontend screens and CSS. You can focus on Backend services and the Supabase project. Changes to the shared models, service method names, root dependencies or configuration should be coordinated.

## What stays the same

- Display name, Email and Password registration.
- The existing welcome screen, artwork and login animation.
- Learner and approved-teacher login, logout and saved sessions.
- The one-question reading activity and first-answer saving.
- Teacher access to all learners and practice records under the existing database policies.
- Existing accounts, learner codes, records, question IDs and SQL function names.

BKT and the full chapter game are not introduced by this reorganization.

## An important distinction

Backend/src is maintained by the backend teammate, but it is a BROWSER API ADAPTER: Vite bundles these functions into the browser app. Moving a file to Backend does not make it a protected server. Approval, authorization, grading and first-answer enforcement still run in Supabase through RLS and the existing RPC.

The supplied ZIP did not contain a live database export. This package therefore does not claim to contain your deployed SQL definitions. Backend/database explains how to inspect/export them. Nothing here automatically runs SQL or changes your database.

## Checks

Run these from the project root:

```powershell
npm.cmd run build
npm.cmd run test:e2e
```

The first checks both backend services and frontend TypeScript before building Frontend/dist. Browser tests use installed Google Chrome and simulated Supabase responses; they do not create live accounts or consume learner codes.

After startup, use your existing learner and teacher test accounts to verify the live project connection. If teacher tables or the signup trigger were changed separately, this code reorganization cannot repair them automatically.

## Replace the earlier GitHub version

This package changes file locations and consolidates dependencies at the root. Use a new Git branch and review additions AND deletions. A browser upload alone does not delete old files.

Files removed from the old version:
- Frontend/package.json and Frontend/package-lock.json: dependencies now live at the root.
- Frontend/src/supabaseClient.ts: replaced by Backend/src/client.ts and Frontend/src/services/api.ts.
- Frontend/database/check_existing_setup.sql: moved to Backend/database/check_existing_setup.sql.

Do not commit .env.local, node_modules, dist or test-results. Include .env.example and .gitignore. The two team folders must stay together; do not upload either ZIP as an application source file.

Next suggested step: open the extracted readquest-main folder in VS Code, create Frontend/.env.local, and run npm.cmd ci at the root.
