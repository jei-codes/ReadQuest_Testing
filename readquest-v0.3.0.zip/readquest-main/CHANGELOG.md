# ReadQuest release history

Newest releases appear first. Dates use Asia/Singapore time.

## v0.3.0 — October 14, 2026

- Added Teacher Register with Display name, Email and Password. The default display name is Teacher.
- New teachers receive a protected registration request, not automatic teacher approval.
- Added an awaiting-approval page with Check approval and Log out.
- Added commented SQL scripts to install the workflow, list requests and approve one confirmed applicant.
- Teacher applicants do not receive learner profiles or appear in the student roster.
- Pending accounts cannot use Student Login; existing wrong-form checks remain in place.
- Added a readiness check to prevent teacher signup before database setup.
- Saved the teacher display name as signup metadata as well as in the request; approval copies it to the teachers table. Approved dashboard labels remain Teacher, as requested previously.
- Required: apply Backend/database/01_teacher_registration_v0.3.0.sql before starting this version.
- Verified: production build, 17 browser tests with simulated responses, and isolated PostgreSQL tests of triggers, row permissions, self-approval denial and administrator approval.
- Live Supabase was not changed or tested. Existing signup trigger definitions must be compatible with the documented ReadQuest setup.

## v0.2.0 — October 14, 2026

### Login and display changes

- Student Login accepts learner accounts only.
- Teacher Login accepts approved teacher accounts only.
- Wrong-form logins show which login form to use without saving a browser session.
- Teacher approval is checked using the database profile before opening a dashboard.
- Approved teachers appear as "Teacher" in the dashboard and top bar; stored database names are unchanged.
- Added explanatory comments and LOGIN_UPDATE.md.

### Release identification

- Added VERSION.md and this changelog.
- Updated the project version in package.json and package-lock.json to 0.2.0.
- Named the source download readquest-v0.2.0.zip.
- No version label was added to the game interface.

### Verification

- Production build and all 12 browser integration tests passed for the login changes using simulated Supabase responses.
- The subsequent version-only update changes documentation and package version metadata, with JSON consistency checked separately.
- No live database migrations or record changes were made. Live Supabase permissions were not tested by the simulated browser tests.

## v0.1.0 — October 13, 2026

The separated project already used 0.1.0 in package.json. This entry records that earlier release; its ZIP did not originally include a version label.

- Separated Frontend screen code from Backend Supabase data-access code.
- Preserved registration, login, reading practice and the teacher dashboard.
- Added setup documentation and a team guide.
- Production build and 9 browser integration tests passed using simulated Supabase responses.

Earlier work before the separated project was not assigned release numbers.
